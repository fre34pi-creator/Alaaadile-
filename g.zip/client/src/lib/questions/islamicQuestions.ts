import type { QuizQuestion } from "../questionTypes";
import { ISLAMIC_QUESTIONS_1_30 } from "./islamicQuestions1to30";
import { ISLAMIC_QUESTIONS_31_65 } from "./islamic31to65";
import { ISLAMIC_QUESTIONS_66_100 } from "./islamic66to100";

export const ISLAMIC_QUESTIONS: QuizQuestion[] = [
  ...ISLAMIC_QUESTIONS_1_30,
  ...ISLAMIC_QUESTIONS_31_65,
  ...ISLAMIC_QUESTIONS_66_100,
].sort((left, right) => left.number - right.number);
