import type { QuestionStageId, QuestionStage, QuizQuestion } from "./questionTypes";
import { ISLAMIC_QUESTIONS } from "./questions/islamicQuestions";
import { NATURE_QUESTIONS } from "./questions/natureQuestions";
import { GEOGRAPHY_MATH_QUESTIONS } from "./questions/geographyMathQuestions";

export type { QuestionStageId, QuestionStage, QuizQuestion } from "./questionTypes";

export const QUESTION_STAGES: Record<QuestionStageId, QuestionStage> = {
  1: {
    id: 1,
    title: "المرحلة الأولى",
    subject: "الفقه الإسلامي والعبادات",
    description: "أحكام العبادات من المسائل الأساسية إلى الأدق، وفق فتاوى واحتياطات السيد السيستاني.",
    firstQuestion: 1,
    lastQuestion: 100,
  },
  2: {
    id: 2,
    title: "المرحلة الثانية",
    subject: "عالم النباتات والحيوانات",
    description: "حقائق الكائنات الحية وخصائصها، والنباتات، والبيئات الطبيعية.",
    firstQuestion: 101,
    lastQuestion: 200,
  },
  3: {
    id: 3,
    title: "المرحلة الثالثة",
    subject: "الجغرافيا والرياضيات",
    description: "عواصم وقارات وجبال وأنهار، ثم مسائل حسابية وألغاز أرقام.",
    firstQuestion: 201,
    lastQuestion: 300,
  },
};

export const PRIZE_STEPS = [
  100, 200, 300, 500, 1_000, 2_000, 4_000, 8_000, 16_000, 32_000,
  64_000, 125_000, 250_000, 500_000, 1_000_000,
] as const;

export const SAFE_LEVELS = [5, 10] as const;
export const ROUND_QUESTION_COUNT = PRIZE_STEPS.length;

export const QUESTIONS: QuizQuestion[] = [
  ...ISLAMIC_QUESTIONS,
  ...NATURE_QUESTIONS,
  ...GEOGRAPHY_MATH_QUESTIONS,
].sort((left, right) => left.number - right.number);

export function getQuestionsForStage(stage: QuestionStageId): QuizQuestion[] {
  return QUESTIONS.filter((question) => question.stage === stage)
    .sort((left, right) => left.number - right.number);
}

function getDifficultyBucket(stage: QuestionStageId, roundIndex: number) {
  const stageQuestions = getQuestionsForStage(stage);
  const start = Math.floor((roundIndex * stageQuestions.length) / ROUND_QUESTION_COUNT);
  const end = Math.floor(((roundIndex + 1) * stageQuestions.length) / ROUND_QUESTION_COUNT);
  return stageQuestions.slice(start, Math.max(start + 1, end));
}

export function createRoundQuestions(
  stage: QuestionStageId,
  random: () => number = Math.random,
): QuizQuestion[] {
  return Array.from({ length: ROUND_QUESTION_COUNT }, (_, roundIndex) => {
    const bucket = getDifficultyBucket(stage, roundIndex);
    const safeRandom = Math.min(Math.max(random(), 0), 0.999999999);
    return bucket[Math.floor(safeRandom * bucket.length)];
  });
}

export function chooseAlternateQuestion(
  stage: QuestionStageId,
  roundIndex: number,
  excludedIds: ReadonlySet<string>,
  random: () => number = Math.random,
): QuizQuestion | undefined {
  const bucket = getDifficultyBucket(stage, roundIndex);
  const candidates = bucket.filter((question) => !excludedIds.has(question.id));
  if (candidates.length === 0) return undefined;
  const safeRandom = Math.min(Math.max(random(), 0), 0.999999999);
  return candidates[Math.floor(safeRandom * candidates.length)];
}
