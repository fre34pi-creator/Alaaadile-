import { describe, expect, it } from "vitest";
import {
  chooseAlternateQuestion,
  createRoundQuestions,
  getQuestionsForStage,
  QUESTIONS,
  QUESTION_STAGES,
} from "./quizData";

const expectedStage = (number: number) => Math.floor((number - 1) / 100) + 1;

describe("بنك أسئلة ليلة المليون", () => {
  it("يحتوي على 300 سؤال مرقم بلا فجوات وموزعاً بالتساوي على المراحل", () => {
    expect(QUESTIONS).toHaveLength(300);
    expect(QUESTIONS.map((question) => question.number)).toEqual(
      Array.from({ length: 300 }, (_, index) => index + 1),
    );
    expect(getQuestionsForStage(1)).toHaveLength(100);
    expect(getQuestionsForStage(2)).toHaveLength(100);
    expect(getQuestionsForStage(3)).toHaveLength(100);
    expect(Object.values(QUESTION_STAGES)).toHaveLength(3);
  });

  it("يعطي كل سؤال نصاً كاملاً وأربعة خيارات ومفتاح إجابة صالحاً ورقم مرحلته الصحيح", () => {
    const ids = new Set<string>();
    const prompts = new Set<string>();
    for (const question of QUESTIONS) {
      expect(question.id.trim()).not.toBe("");
      expect(ids.has(question.id)).toBe(false);
      ids.add(question.id);
      expect(question.prompt.trim().length).toBeGreaterThan(10);
      expect(prompts.has(question.prompt)).toBe(false);
      prompts.add(question.prompt);
      expect(question.options).toHaveLength(4);
      expect(new Set(question.options).size).toBe(4);
      expect(question.options.every((option) => option.trim().length > 0)).toBe(true);
      expect(Number.isInteger(question.answer)).toBe(true);
      expect(question.answer).toBeGreaterThanOrEqual(0);
      expect(question.answer).toBeLessThan(4);
      expect(question.stage).toBe(expectedStage(question.number));
    }
  });

  it("يوثق كل سؤال في المرحلة الفقهية بمصدر رسمي للسيد السيستاني", () => {
    for (const question of getQuestionsForStage(1)) {
      expect(question.source).toMatch(/^https:\/\/(www\.)?sistani\.org\//);
      expect(question.sourceTitle?.trim().length).toBeGreaterThan(0);
    }
  });

  it("ينتقي 15 سؤالاً فريداً ومتدرجاً من المرحلة المحددة", () => {
    for (const stage of [1, 2, 3] as const) {
      const round = createRoundQuestions(stage, () => 0.5);
      expect(round).toHaveLength(15);
      expect(new Set(round.map((question) => question.id)).size).toBe(15);
      expect(round.every((question) => question.stage === stage)).toBe(true);
      expect(round.map((question) => question.number)).toEqual(
        [...round].map((question) => question.number).sort((a, b) => a - b),
      );
    }
  });

  it("يستبدل السؤال ببديل غير مستخدم من شريحة الصعوبة نفسها", () => {
    const stage: 2 = 2;
    const round = createRoundQuestions(stage, () => 0.5);
    const roundIndex = 7;
    const excluded = new Set(round.map((question) => question.id));
    const alternate = chooseAlternateQuestion(stage, roundIndex, excluded, () => 0.5);
    const stageBank = getQuestionsForStage(stage);
    const first = Math.floor((roundIndex * stageBank.length) / 15);
    const end = Math.floor(((roundIndex + 1) * stageBank.length) / 15);
    expect(alternate).toBeDefined();
    expect(alternate?.stage).toBe(stage);
    expect(excluded.has(alternate?.id ?? "")).toBe(false);
    expect(alternate?.number).toBeGreaterThanOrEqual(stageBank[first].number);
    expect(alternate?.number).toBeLessThanOrEqual(stageBank[end - 1].number);
  });
});
