export type QuestionStageId = 1 | 2 | 3;

export type QuizQuestion = {
  id: string;
  number: number;
  stage: QuestionStageId;
  prompt: string;
  options: [string, string, string, string];
  answer: number;
  source?: string;
  sourceTitle?: string;
};

export type QuestionStage = {
  id: QuestionStageId;
  title: string;
  subject: string;
  description: string;
  firstQuestion: number;
  lastQuestion: number;
};
