import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronLeft,
  CircleHelp,
  Crown,
  EyeOff,
  Lightbulb,
  Medal,
  Music2,
  PartyPopper,
  RotateCcw,
  Shuffle,
  Sparkles,
  Trophy,
  UsersRound,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import {
  chooseAlternateQuestion,
  createRoundQuestions,
  PRIZE_STEPS,
  QUESTION_STAGES,
  ROUND_QUESTION_COUNT,
  SAFE_LEVELS,
  type QuizQuestion,
  type QuestionStageId,
} from "@/lib/quizData";

type GameView = "intro" | "playing" | "lost" | "won";
type AnswerPhase = "pending" | "correct" | "wrong" | null;
type SoundName = "click" | "correct" | "wrong" | "win";
type Currency = "ريال" | "دولار";

const OPTION_LETTERS = ["أ", "ب", "ج", "د"];
const moneyFormat = new Intl.NumberFormat("en-US");

function formatPrize(value: number, currency: Currency) {
  return `${moneyFormat.format(value)} ${currency}`;
}

function getAudienceShares(question: QuizQuestion, level: number) {
  const correctShare = Math.round(Math.max(27, 72 - level * 2.5 + Math.random() * 12));
  const remainder = 100 - correctShare;
  const weights = [Math.random() + 0.15, Math.random() + 0.15, Math.random() + 0.15];
  const weightTotal = weights.reduce((sum, value) => sum + value, 0);
  const wrongShares = weights.map((weight) => Math.floor((weight / weightTotal) * remainder));
  wrongShares[0] += remainder - wrongShares.reduce((sum, value) => sum + value, 0);
  const shares = [0, 0, 0, 0];
  let wrongIndex = 0;
  question.options.forEach((_, optionIndex) => {
    if (optionIndex === question.answer) shares[optionIndex] = correctShare;
    else shares[optionIndex] = wrongShares[wrongIndex++];
  });
  return shares;
}

function playSequence(context: AudioContext, notes: number[], duration: number, spacing: number) {
  const now = context.currentTime;
  notes.forEach((frequency, index) => {
    const startAt = now + index * spacing;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(frequency, startAt);
    gain.gain.setValueAtTime(0.0001, startAt);
    gain.gain.exponentialRampToValueAtTime(0.075, startAt + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(startAt);
    oscillator.stop(startAt + duration + 0.03);
  });
}

export default function Home() {
  const [view, setView] = useState<GameView>("intro");
  const [selectedStage, setSelectedStage] = useState<QuestionStageId>(1);
  const [questions, setQuestions] = useState<QuizQuestion[]>(() => createRoundQuestions(1));
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answerPhase, setAnswerPhase] = useState<AnswerPhase>(null);
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([]);
  const [usedLifelines, setUsedLifelines] = useState({ fifty: false, switch: false, audience: false });
  const [audienceOpen, setAudienceOpen] = useState(false);
  const [audienceShares, setAudienceShares] = useState<number[]>([]);
  const [ladderOpen, setLadderOpen] = useState(true);
  const [currency, setCurrency] = useState<Currency>("ريال");
  const [muted, setMuted] = useState(false);
  const audioContext = useRef<AudioContext | null>(null);

  const currentQuestion = questions[questionIndex];
  const prizeAtRisk = PRIZE_STEPS[questionIndex] ?? PRIZE_STEPS[0];
  const safePrize = useMemo(() => {
    if (questionIndex > SAFE_LEVELS[1] - 1) return PRIZE_STEPS[SAFE_LEVELS[1] - 1];
    if (questionIndex > SAFE_LEVELS[0] - 1) return PRIZE_STEPS[SAFE_LEVELS[0] - 1];
    return 0;
  }, [questionIndex]);

  const playSound = useCallback((sound: SoundName) => {
    if (muted || typeof window === "undefined") return;
    const AudioContextConstructor = window.AudioContext;
    if (!AudioContextConstructor) return;
    const context = audioContext.current ?? new AudioContextConstructor();
    audioContext.current = context;
    if (context.state === "suspended") void context.resume();
    const sequences: Record<SoundName, { notes: number[]; duration: number; spacing: number }> = {
      click: { notes: [820], duration: 0.07, spacing: 0.08 },
      correct: { notes: [660, 830, 990], duration: 0.18, spacing: 0.11 },
      wrong: { notes: [440, 370, 294], duration: 0.28, spacing: 0.18 },
      win: { notes: [523, 659, 784, 1047], duration: 0.32, spacing: 0.15 },
    };
    const sequence = sequences[sound];
    playSequence(context, sequence.notes, sequence.duration, sequence.spacing);
  }, [muted]);

  useEffect(() => () => {
    if (audioContext.current && audioContext.current.state !== "closed") {
      void audioContext.current.close();
    }
  }, []);

  useEffect(() => {
    if (!audienceOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setAudienceOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [audienceOpen]);

  const startGame = () => {
    setQuestions(createRoundQuestions(selectedStage));
    setQuestionIndex(0);
    setSelectedAnswer(null);
    setAnswerPhase(null);
    setEliminatedOptions([]);
    setUsedLifelines({ fifty: false, switch: false, audience: false });
    setAudienceShares([]);
    setAudienceOpen(false);
    setView("playing");
    playSound("click");
  };

  const answerQuestion = (optionIndex: number) => {
    if (view !== "playing" || selectedAnswer !== null || eliminatedOptions.includes(optionIndex)) return;
    setSelectedAnswer(optionIndex);
    setAnswerPhase("pending");
    playSound("click");
    window.setTimeout(() => {
      const isCorrect = optionIndex === currentQuestion.answer;
      setAnswerPhase(isCorrect ? "correct" : "wrong");
      if (!isCorrect) {
        setView("lost");
        playSound("wrong");
      } else if (questionIndex === PRIZE_STEPS.length - 1) {
        setView("won");
        playSound("win");
      } else {
        playSound("correct");
      }
    }, 2000);
  };

  const continueGame = () => {
    if (questionIndex >= PRIZE_STEPS.length - 1) return;
    setQuestionIndex((previous) => previous + 1);
    setSelectedAnswer(null);
    setAnswerPhase(null);
    setEliminatedOptions([]);
    playSound("click");
  };

  const useFiftyFifty = () => {
    if (usedLifelines.fifty || view !== "playing" || selectedAnswer !== null) return;
    const wrongAnswers = [0, 1, 2, 3].filter((index) => index !== currentQuestion.answer);
    const removed = wrongAnswers.sort(() => Math.random() - 0.5).slice(0, 2);
    setEliminatedOptions(removed);
    setUsedLifelines((previous) => ({ ...previous, fifty: true }));
    playSound("click");
  };

  const changeQuestion = () => {
    if (usedLifelines.switch || view !== "playing" || selectedAnswer !== null) return;
    const excludedIds = new Set(questions.map((question) => question.id));
    const alternate = chooseAlternateQuestion(currentQuestion.stage, questionIndex, excludedIds);
    if (!alternate) return;
    setQuestions((previous) => previous.map((question, index) => index === questionIndex ? alternate : question));
    setEliminatedOptions([]);
    setUsedLifelines((previous) => ({ ...previous, switch: true }));
    playSound("click");
  };

  const askAudience = () => {
    if (usedLifelines.audience || view !== "playing" || selectedAnswer !== null) return;
    setAudienceShares(getAudienceShares(currentQuestion, questionIndex + 1));
    setUsedLifelines((previous) => ({ ...previous, audience: true }));
    setAudienceOpen(true);
    playSound("click");
  };

  const restartGame = () => {
    setView("intro");
    setQuestions(createRoundQuestions(selectedStage));
    setQuestionIndex(0);
    setSelectedAnswer(null);
    setAnswerPhase(null);
    setEliminatedOptions([]);
    setUsedLifelines({ fifty: false, switch: false, audience: false });
    setAudienceShares([]);
    setAudienceOpen(false);
    setLadderOpen(true);
    playSound("click");
  };

  const isActionLocked = view !== "playing" || selectedAnswer !== null;
  const displayedPrize = view === "won" ? PRIZE_STEPS[PRIZE_STEPS.length - 1] : safePrize;

  return (
    <div className="app-shell" dir="rtl">
      <div className="ambient-glow ambient-glow-one" />
      <div className="ambient-glow ambient-glow-two" />
      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="/" aria-label="ليلة المليون، الصفحة الرئيسية" onClick={(event) => event.preventDefault()}>
            <span className="brand-seal" aria-hidden="true"><Crown size={19} strokeWidth={1.7} /></span>
            <span className="brand-copy"><strong>ليلة المليون</strong><small>تحدّي المعرفة</small></span>
          </a>
          <div className="header-controls">
            <div className="currency-toggle" role="group" aria-label="اختر وحدة عرض الجائزة الافتراضية" title="تبديل وحدة عرض الجوائز الافتراضية؛ لا توجد عملية تحويل نقدي">
              {(["ريال", "دولار"] as const).map((unit) => (
                <button key={unit} className={currency === unit ? "currency-option is-active" : "currency-option"} onClick={() => { setCurrency(unit); playSound("click"); }}>
                  {unit}
                </button>
              ))}
            </div>
            <button className="sound-toggle" onClick={() => { setMuted((value) => !value); if (muted) playSound("click"); }} aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"} title={muted ? "تشغيل الصوت" : "كتم الصوت"}>
              {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
              <span>{muted ? "الصوت مكتوم" : "الصوت يعمل"}</span>
            </button>
          </div>
        </div>
      </header>

      {view === "intro" ? (
        <main className="main-wrap intro-wrap">
          <section className="intro-scene" aria-labelledby="intro-title">
            <div className="intro-copy">
              <div className="eyebrow"><span className="eyebrow-line" /> ثلاث مراحل، وثلاثمئة سؤال</div>
              <h1 id="intro-title">هل تملك الإجابة<br /><span>لتصل إلى المليون؟</span></h1>
              <p className="intro-description">اختر مرحلة من بنك يضم 300 سؤال، ثم أجب عن 15 سؤالاً متدرجاً من موضوعها. ثلاث وسائل مساعدة وخطوة واحدة تفصلك عن كل جائزة.</p>
              <div className="intro-stats">
                <div className="intro-stat"><span className="stat-icon"><CircleHelp size={18} /></span><span><strong>300</strong><small>سؤال في البنك</small></span></div>
                <div className="intro-stat"><span className="stat-icon"><Sparkles size={18} /></span><span><strong>3</strong><small>وسائل مساعدة</small></span></div>
                <div className="intro-stat"><span className="stat-icon"><Trophy size={18} /></span><span><strong>1,000,000</strong><small>{currency}</small></span></div>
              </div>
              <div className="stage-picker" role="group" aria-label="اختر مرحلة المسابقة">
                {Object.values(QUESTION_STAGES).map((stage) => (
                  <button
                    key={stage.id}
                    type="button"
                    className={`stage-choice ${selectedStage === stage.id ? "is-selected" : ""}`}
                    onClick={() => { setSelectedStage(stage.id); playSound("click"); }}
                    aria-pressed={selectedStage === stage.id}
                  >
                    <span className="stage-choice-number">0{stage.id}</span>
                    <strong>{stage.title}</strong>
                    <span className="stage-choice-subject">{stage.subject}</span>
                    <span className="stage-choice-description">{stage.description}</span>
                    <small>100 سؤال</small>
                  </button>
                ))}
              </div>
              <button className="primary-button start-button" onClick={startGame}>
                ابدأ التحدّي <ChevronLeft size={19} />
              </button>
              <p className="quiet-note"><Music2 size={14} /> الأصوات اختيارية ويمكن كتمها في أي وقت</p>
            </div>
            <div className="intro-visual" aria-hidden="true">
              <div className="visual-orbit orbit-outer" />
              <div className="visual-orbit orbit-inner" />
              <div className="medallion-halo"><span className="halo-dot dot-one" /><span className="halo-dot dot-two" /><span className="halo-dot dot-three" /></div>
              <div className="grand-medallion">
                <div className="medallion-crown"><Crown size={32} strokeWidth={1.4} /></div>
                <span className="medallion-caption">الجائزة الكبرى</span>
                <strong>1,000,000</strong>
                <span className="medallion-currency">{currency}</span>
              </div>
              <div className="orbit-label orbit-label-top"><Medal size={14} /> ثلاث مراحل رئيسية</div>
              <div className="orbit-label orbit-label-bottom"><Sparkles size={14} /> اصنع لحظتك</div>
              <div className="visual-spark spark-a">✦</div><div className="visual-spark spark-b">✦</div><div className="visual-spark spark-c">·</div>
            </div>
          </section>
          <div className="intro-footnote"><span className="footnote-mark"><Lightbulb size={16} /></span><span>تُختار أسئلة الجولة الخمسة عشر من المرحلة المحددة بترتيب متدرج من السهل إلى الأصعب. الإجابة الصحيحة ترفعك درجة، والخاطئة تكشف الحل. يظهر مصدر المسألة الفقهية بعد الإجابة؛ والجوائز افتراضية ويمكنك إعادة اللعب متى شئت.</span></div>
        </main>
      ) : (
        <main className="main-wrap game-wrap">
          <div className="game-heading">
            <div><p className="eyebrow"><span className="eyebrow-line" /> {QUESTION_STAGES[selectedStage].title} · {QUESTION_STAGES[selectedStage].subject}</p><h1>كل إجابة تقرّبك</h1></div>
              <div className="round-progress" aria-label={`محطة الجولة ${questionIndex + 1} من ${ROUND_QUESTION_COUNT}`}>
              <span className="round-progress-label">محطة الجولة</span><strong>{String(questionIndex + 1).padStart(2, "0")}<i> / {ROUND_QUESTION_COUNT}</i></strong>
            </div>
          </div>
          <div className="game-layout">
            <section className="game-main" aria-label="منطقة السؤال">
              <div className="lifelines" aria-label="وسائل المساعدة">
                <button className={`lifeline-button ${usedLifelines.fifty ? "is-used" : ""}`} onClick={useFiftyFifty} disabled={isActionLocked || usedLifelines.fifty}>
                  <span className="lifeline-icon"><EyeOff size={19} /></span><span className="lifeline-label"><strong>50 : 50</strong><small>حذف إجابتين</small></span><span className="lifeline-count">{usedLifelines.fifty ? "استُخدمت" : "×1"}</span>
                </button>
                <button className={`lifeline-button ${usedLifelines.switch ? "is-used" : ""}`} onClick={changeQuestion} disabled={isActionLocked || usedLifelines.switch}>
                  <span className="lifeline-icon"><Shuffle size={18} /></span><span className="lifeline-label"><strong>تغيير السؤال</strong><small>سؤال بديل للمستوى</small></span><span className="lifeline-count">{usedLifelines.switch ? "استُخدمت" : "×1"}</span>
                </button>
                <button className={`lifeline-button ${usedLifelines.audience ? "is-used" : ""}`} onClick={askAudience} disabled={isActionLocked || usedLifelines.audience}>
                  <span className="lifeline-icon"><UsersRound size={19} /></span><span className="lifeline-label"><strong>رأي الجمهور</strong><small>نسب تصويت تقديرية</small></span><span className="lifeline-count">{usedLifelines.audience ? "استُخدمت" : "×1"}</span>
                </button>
              </div>

              <div className="question-shell">
                <div className="question-card">
                  <div className="question-topline"><span className="question-index">محطة {String(questionIndex + 1).padStart(2, "0")} · سؤال البنك {currentQuestion.number}</span><span className="question-prize"><Trophy size={15} /> {formatPrize(prizeAtRisk, currency)}</span></div>
                  <h2 className="question-text">{currentQuestion.prompt}</h2>
                  <span className="question-hint">{QUESTION_STAGES[currentQuestion.stage].title} · {QUESTION_STAGES[currentQuestion.stage].subject} · اختر إجابة واحدة</span>
                </div>
              </div>

              <div className="answers-grid" aria-label="خيارات الإجابة">
                {currentQuestion.options.map((option, optionIndex) => {
                  const isSelected = selectedAnswer === optionIndex;
                  const isCorrectOption = currentQuestion.answer === optionIndex;
                  let stateClass = "";
                  if (isSelected && answerPhase === "pending") stateClass = "is-pending";
                  if (isSelected && answerPhase === "correct") stateClass = "is-correct";
                  if (isSelected && answerPhase === "wrong") stateClass = "is-wrong";
                  if (!isSelected && isCorrectOption && answerPhase === "wrong") stateClass = "is-revealed-correct";
                  const isEliminated = eliminatedOptions.includes(optionIndex);
                  return (
                    <button
                      key={`${currentQuestion.id}-${optionIndex}`}
                      className={`answer-button ${stateClass} ${isEliminated ? "is-eliminated" : ""}`}
                      onClick={() => answerQuestion(optionIndex)}
                      disabled={isActionLocked || isEliminated}
                      aria-label={`الخيار ${OPTION_LETTERS[optionIndex]}: ${option}`}
                    >
                      <span className="answer-content"><span className="answer-letter">{OPTION_LETTERS[optionIndex]}</span><span className="answer-copy">{option}</span>{isSelected && answerPhase === "correct" ? <Check className="answer-state-icon" size={17} /> : null}</span>
                    </button>
                  );
                })}
              </div>

              {selectedAnswer === null ? (
                <div className="answer-guidance"><span className="guidance-dot" /> اختر بحكمة؛ لا يمكن تغيير الاختيار بعد تأكيده.</div>
              ) : answerPhase === "pending" ? (
                <div className="feedback-banner is-thinking" role="status"><span className="thinking-pulse" /> لحظة الحسم... نراجع الإجابة</div>
              ) : answerPhase === "correct" ? (
                <div className="feedback-banner is-right" role="status"><span className="feedback-icon"><Check size={17} /></span><span><strong>إجابة صحيحة!</strong><small>أحسنت، أنت على بُعد خطوة أخرى.</small></span></div>
              ) : (
                <div className="feedback-banner is-wrong-result" role="status"><span className="feedback-icon"><X size={17} /></span><span><strong>انتهت الجولة هنا</strong><small>الإجابة الصحيحة: {currentQuestion.options[currentQuestion.answer]}</small></span></div>
              )}

              {answerPhase !== null && currentQuestion.source ? (
                <a className="question-source" href={currentQuestion.source} target="_blank" rel="noopener noreferrer">
                  المصدر الفقهي الرسمي: {currentQuestion.sourceTitle ?? "موقع السيد السيستاني"}
                </a>
              ) : null}

              {answerPhase === "correct" && view === "playing" ? (
                <button className="primary-button continue-button" onClick={continueGame}>السؤال التالي <ChevronLeft size={18} /></button>
              ) : null}
              {(view === "lost" || view === "won") ? (
                <div className={`end-card ${view === "won" ? "is-victory" : "is-defeat"}`}>
                  <span className="end-emblem">{view === "won" ? <PartyPopper size={22} /> : <Trophy size={22} />}</span>
                  <div className="end-copy"><strong>{view === "won" ? "المليون لك!" : "جولة ثرية بالمعلومات"}</strong><span>{view === "won" ? "أجبت عن الأسئلة الخمسة عشر كلها." : `تغادر ومعك ${formatPrize(displayedPrize, currency)}.`}</span></div>
                  <button className="replay-button" onClick={restartGame}><RotateCcw size={16} /> جولة جديدة</button>
                </div>
              ) : null}
            </section>

            <aside className="prize-panel" aria-label="سُلّم الجوائز">
              <button className="prize-panel-heading" onClick={() => setLadderOpen((open) => !open)} aria-expanded={ladderOpen}>
                <span className="prize-panel-title"><span className="panel-crown"><Crown size={15} /></span><span><strong>سُلّم الجوائز</strong><small>محطات نحو القمة</small></span></span>
                <span className={`ladder-chevron ${ladderOpen ? "is-open" : ""}`}><ChevronDown size={18} /></span>
              </button>
              {ladderOpen ? (
                <ol className="prize-list">
                  {[...PRIZE_STEPS].map((prize, index) => ({ prize, level: index + 1 })).reverse().map(({ prize, level }) => {
                    const isCurrent = view === "playing" && level === questionIndex + 1;
                    const isPast = level <= questionIndex;
                    const isSafe = SAFE_LEVELS.includes(level as (typeof SAFE_LEVELS)[number]);
                    return (
                      <li key={level} className={`prize-step ${isCurrent ? "is-current" : ""} ${isPast ? "is-past" : ""} ${isSafe ? "is-safe" : ""}`} aria-current={isCurrent ? "step" : undefined}>
                        <span className="step-number">{String(level).padStart(2, "0")}</span>
                        <span className="step-amount">{moneyFormat.format(prize)} <small>{currency}</small></span>
                        {isSafe ? <span className="safe-mark" title="محطة أمان"><Medal size={13} /></span> : <span className="step-dot" />}
                      </li>
                    );
                  })}
                </ol>
              ) : <div className="ladder-collapsed-note">افتح السلم لمتابعة الجوائز</div>}
              <div className="prize-panel-foot"><span className="safe-legend"><Medal size={13} /> محطة أمان</span><span>{questionIndex + 1} من {ROUND_QUESTION_COUNT}</span></div>
            </aside>
          </div>
          <footer className="game-footer"><span><Sparkles size={14} /> لعبة أصلية لتحدّي المعرفة</span><span>كل جولة فرصة جديدة</span></footer>
        </main>
      )}

      {audienceOpen ? (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setAudienceOpen(false); }}>
          <section className="audience-modal" role="dialog" aria-modal="true" aria-labelledby="audience-title">
            <button className="modal-close" onClick={() => setAudienceOpen(false)} aria-label="إغلاق رأي الجمهور"><X size={18} /></button>
            <div className="modal-kicker"><UsersRound size={15} /> تقدير رأي الجمهور</div>
            <h2 id="audience-title">ماذا يظن الجمهور؟</h2>
            <p className="audience-question">{currentQuestion.prompt}</p>
            <div className="audience-chart" role="img" aria-label="رسم بياني تقديري بنسب تصويت الجمهور على الخيارات">
              {currentQuestion.options.map((option, index) => (
                <div className="audience-column" key={`poll-${option}`}>
                  <div className="audience-value">{audienceShares[index] ?? 0}%</div>
                  <div className="audience-bar-track"><div className={`audience-bar ${index === currentQuestion.answer ? "is-leading" : ""}`} style={{ height: `${Math.max(4, audienceShares[index] ?? 0)}%` }} /></div>
                  <span className="audience-letter">{OPTION_LETTERS[index]}</span>
                  <span className="audience-option">{option}</span>
                </div>
              ))}
            </div>
            <p className="audience-disclaimer">النسب تقديرية — القرار الأخير لك.</p>
            <button className="primary-button modal-done" onClick={() => setAudienceOpen(false)}>حسناً، سأختار <Check size={17} /></button>
          </section>
        </div>
      ) : null}

      <div className="sound-caption" aria-live="polite">{muted ? "الصوت مكتوم" : ""}</div>
    </div>
  );
}
